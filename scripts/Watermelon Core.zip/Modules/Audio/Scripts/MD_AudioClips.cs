﻿using System.Collections.Generic;
using UnityEngine;

namespace Watermelon
{
    [CreateAssetMenu(fileName = "Audio Clips", menuName = "Data/Core/Audio Clips")]
    public class AudioClips : ScriptableObject
    {
        [BoxGroup("UI", "UI")]
        public AudioClip buttonSound;

        [BoxGroup("Gameplay", "Gameplay")]
        public AudioClip winSound;
        [BoxGroup("Gameplay")]
        public AudioClip looseSound;
        [BoxGroup("Gameplay")]
        public AudioClip bounce;
        [BoxGroup("Gameplay")]
        public AudioClip bounceSpawn;
    }
}

// -----------------
// Audio Controller v 0.4
// -----------------