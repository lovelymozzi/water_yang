﻿namespace Watermelon
{
    // DO NOT CHANGE ORDER OF THE CURRENCIES AFTER RELEASE. IT CAN BRAKE THE SAVES OF THE GAME!
    public enum CurrencyType
    {
        Money = 0,
        TempMoney = 1,
        Gems = 2,
    }
}